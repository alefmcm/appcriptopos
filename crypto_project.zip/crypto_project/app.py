# app_streamlit.py
import streamlit as st
from crypto import generate_rsa_keypair, hybrid_encrypt, hybrid_decrypt, sign, verify_signature
import models
import base64

st.set_page_config(page_title="Comunicação Segura", layout="centered")
models.init_db()

st.title("🔐 Comunicação Segura (RSA + AES-GCM + SHA-256)")

tabs = st.tabs(["Registrar Usuário", "Enviar Mensagem", "Inbox", "Chaves / Export"])

# -------------------- Registrar Usuário --------------------
with tabs[0]:
    st.header("Registrar usuário")
    new_user = st.text_input("Nome do usuário (ex: Alice)")
    col1, col2 = st.columns(2)
    bits = col1.selectbox("Tamanho da chave RSA", [2048, 3072, 4096], index=0)
    if col2.button("Criar usuário"):
        if not new_user:
            st.warning("Informe um nome de usuário.")
        else:
            priv, pub = generate_rsa_keypair(bits=bits)
            models.add_user(new_user.strip(), pub, priv)
            st.success(f"Usuário '{new_user}' criado. Chave RSA {bits} bits gerada.")
            st.code(pub.decode(), language="pem")
            st.info("A chave privada também foi salva no banco para fins de demonstração (em produção, use armazenamento seguro).")

# -------------------- Enviar Mensagem --------------------
with tabs[1]:
    st.header("Enviar mensagem (criptografar + assinar)")
    users = models.list_users()
    if len(users) < 2:
        st.info("Precisamos de pelo menos 2 usuários para enviar mensagens. Crie-os na aba 'Registrar Usuário'.")
    sender = st.selectbox("Remetente", options=users)
    recipient = st.selectbox("Destinatário", options=[u for u in users if u != sender])
    message_text = st.text_area("Mensagem", height=150)
    if st.button("Enviar"):
        if not sender or not recipient or not message_text:
            st.warning("Preencha remetente, destinatário e mensagem.")
        else:
            recipient_pub = models.get_public_key(recipient)
            sender_priv = models.get_private_key(sender)
            if not recipient_pub or not sender_priv:
                st.error("Erro: chaves não encontradas.")
            else:
                payload = hybrid_encrypt(recipient_pub, message_text.encode('utf-8'))
                signature = sign(sender_priv, message_text.encode('utf-8'))
                models.store_message(sender, recipient, payload, signature)
                st.success("Mensagem enviada e armazenada (cifrada).")
                st.write("Assinatura (base64):")
                st.code(signature)

# -------------------- Inbox --------------------
with tabs[2]:
    st.header("Inbox (decifrar e verificar)")
    users = models.list_users()
    selected_user = st.selectbox("Escolha o usuário para ver as mensagens", users)
    if selected_user:
        msgs = models.list_messages_for(selected_user)
        if not msgs:
            st.info("Nenhuma mensagem encontrada para este usuário.")
        else:
            for m in msgs:
                mid, sender, payload_blob, signature_b64, timestamp = m
                with st.expander(f"ID {mid} — From: {sender} — {timestamp}"):
                    st.write("Signature (base64):")
                    st.code(signature_b64)
                    if st.button(f"Decifrar mensagem {mid}", key=f"open_{mid}"):
                        priv = models.get_private_key(selected_user)
                        sender_pub = models.get_public_key(sender)
                        try:
                            # payload_blob might be bytes object (sqlite3.Binary)
                            if isinstance(payload_blob, memoryview):
                                payload_bytes = payload_blob.tobytes()
                            else:
                                payload_bytes = payload_blob
                            plaintext = hybrid_decrypt(priv, payload_bytes)
                            text = plaintext.decode('utf-8')
                            st.success("Mensagem decifrada:")
                            st.write(text)
                            verified = verify_signature(sender_pub, plaintext, signature_b64)
                            if verified:
                                st.success("Assinatura verificada ✅")
                            else:
                                st.error("Falha na verificação da assinatura ❌")
                        except Exception as e:
                            st.error(f"Erro ao decifrar/verificar: {e}")

# -------------------- Chaves / Export --------------------
with tabs[3]:
    st.header("Exportar / visualizar chaves")
    users = models.list_users()
    user_for_keys = st.selectbox("Escolha usuário", options=users)
    if user_for_keys:
        pub = models.get_public_key(user_for_keys)
        priv = models.get_private_key(user_for_keys)
        if pub:
            st.subheader("Chave pública")
            st.code(pub.decode(), language="pem")
            st.download_button("Download chave pública (PEM)", data=pub, file_name=f"{user_for_keys}_pub.pem")
        if priv:
            st.subheader("Chave privada")
            st.code(priv.decode(), language="pem")
            st.warning("Chave privada visível apenas para demonstração. Em produção, não exponha assim.")
            st.download_button("Download chave privada (PEM)", data=priv, file_name=f"{user_for_keys}_priv.pem")

# Footer
st.markdown("---")
st.caption("App didático: RSA + AES-GCM + SHA-256. Não use tal armazenamento de chave em produção sem proteções adicionais (HSM, senhas, TLS).")
