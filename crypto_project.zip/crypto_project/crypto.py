import os, json, base64
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP, AES
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256
from Crypto.Random import get_random_bytes

def generate_rsa_keypair(bits=2048):
    key = RSA.generate(bits)
    private = key.export_key()
    public = key.publickey().export_key()
    return private, public

def rsa_encrypt(public_key_pem, data_bytes):
    rsa_key = RSA.import_key(public_key_pem)
    cipher = PKCS1_OAEP.new(rsa_key)
    return cipher.encrypt(data_bytes)

def rsa_decrypt(private_key_pem, cipher_bytes):
    rsa_key = RSA.import_key(private_key_pem)
    cipher = PKCS1_OAEP.new(rsa_key)
    return cipher.decrypt(cipher_bytes)

def aes_encrypt(data_bytes):
    key = get_random_bytes(32)
    cipher = AES.new(key, AES.MODE_GCM)
    ciphertext, tag = cipher.encrypt_and_digest(data_bytes)
    return {'key': key, 'ciphertext': ciphertext, 'nonce': cipher.nonce, 'tag': tag}

def aes_decrypt(key, nonce, ciphertext, tag):
    cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
    data = cipher.decrypt_and_verify(ciphertext, tag)
    return data

def hybrid_encrypt(recipient_public_pem, plaintext_bytes):
    aes_res = aes_encrypt(plaintext_bytes)
    encrypted_key = rsa_encrypt(recipient_public_pem, aes_res['key'])
    payload = {
        'encrypted_key': base64.b64encode(encrypted_key).decode(),
        'ciphertext': base64.b64encode(aes_res['ciphertext']).decode(),
        'nonce': base64.b64encode(aes_res['nonce']).decode(),
        'tag': base64.b64encode(aes_res['tag']).decode()
    }
    return json.dumps(payload).encode()

def hybrid_decrypt(recipient_private_pem, payload_bytes):
    payload = json.loads(payload_bytes.decode())
    encrypted_key = base64.b64decode(payload['encrypted_key'])
    key = rsa_decrypt(recipient_private_pem, encrypted_key)
    ciphertext = base64.b64decode(payload['ciphertext'])
    nonce = base64.b64decode(payload['nonce'])
    tag = base64.b64decode(payload['tag'])
    plaintext = aes_decrypt(key, nonce, ciphertext, tag)
    return plaintext

def sha256_digest(data_bytes):
    return SHA256.new(data=data_bytes)

def sign(private_key_pem, data_bytes):
    key = RSA.import_key(private_key_pem)
    h = sha256_digest(data_bytes)
    signer = pkcs1_15.new(key)
    signature = signer.sign(h)
    return base64.b64encode(signature).decode()

def verify_signature(public_key_pem, data_bytes, signature_b64):
    key = RSA.import_key(public_key_pem)
    h = sha256_digest(data_bytes)
    signature = base64.b64decode(signature_b64)
    try:
        pkcs1_15.new(key).verify(h, signature)
        return True
    except (ValueError, TypeError):
        return False
